
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'solarnius',
  applicationName: 'classify-serverless',
  appUid: '7jBNHmqTmzsLLPq0Tk',
  orgUid: 'c330c6dc-0a1b-48e4-85b2-7a02b43f18a5',
  deploymentUid: '6ccf0fb5-ca45-488e-9570-0ad66472d960',
  serviceName: 'classify-serverless',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '7.2.0',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'classify-serverless-dev-classify', timeout: 30 };

try {
  const userHandler = require('./classify.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}