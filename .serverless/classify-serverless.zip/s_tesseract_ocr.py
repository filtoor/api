import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='solarnius',
    application_name='classify-serverless',
    app_uid='7jBNHmqTmzsLLPq0Tk',
    org_uid='c330c6dc-0a1b-48e4-85b2-7a02b43f18a5',
    deployment_uid='191d4b91-dfb0-4163-a80e-606d711a993a',
    service_name='classify-serverless',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='7.2.0',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'classify-serverless-dev-tesseract-ocr', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('handler.main')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
